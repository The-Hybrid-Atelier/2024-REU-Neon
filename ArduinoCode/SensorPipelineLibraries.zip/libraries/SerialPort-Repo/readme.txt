The SerialPort library provide more options for buffering, character size,
parity and error checking than the standard Arduino HardwareSerial
class for AVR Arduino boards.

An example high speed serial data-logger is included.

To install the this library, copy the SerialPort folder to the
your libraries directory.

Try the HelloWorld example first.

The API was designed to be backward compatible with Arduino Serial.
A number of functions have been added to the API.

Read the html files for more information.
